# Deploying SWP'sGift — your path

You chose **Hugging Face Spaces** for hosting, **GitHub** for the code, and **Google
Programmable Search** for web plagiarism checking. Here is the whole thing, in order.

Total time: about 10 minutes. No credit card anywhere.

---

## Step 1 — Create the Space (2 minutes)

1. Sign in at <https://huggingface.co> (free account).
2. Open <https://huggingface.co/new-space>.
3. Fill in exactly:

   | Field | Value |
   |---|---|
   | Owner | your username |
   | Space name | `swpsgift` |
   | License | `MIT` (or leave blank) |
   | SDK | **Docker** |
   | Docker template | **Blank** |
   | Hardware | **CPU basic · 2 vCPU · 16 GB · FREE** |
   | Visibility | **Public** |

4. Click **Create Space**. It will start building an empty container that fails — that is fine,
   you are about to replace the files.

Your Space URL will be:

- page: `https://huggingface.co/spaces/<username>/swpsgift`
- direct app: `https://<username>-swpsgift.hf.space`

---

## Step 2 — Upload the files (3 minutes)

Use **`swpsgift-space.zip`** from your workspace (already built for Spaces: the `README.md` at its
root carries the `sdk: docker` / `app_port: 7860` configuration that Hugging Face requires).

**Easy way — web upload:**

1. Download `swpsgift-space.zip` and unzip it.
2. In your Space, open the **Files** tab → **Add file** → **Upload files**.
3. Drag in **the contents** of the unzipped folder (not the folder itself): `README.md`,
   `Dockerfile`, `requirements.txt`, the `app/` folder, `.env.example`.
   Make sure `README.md` overwrites the one Spaces generated.
4. **Commit changes to `main`.**

**Command-line way (if you prefer git):**

```bash
git clone https://huggingface.co/spaces/<username>/swpsgift
cd swpsgift
unzip ~/Downloads/swpsgift-space.zip -d .
# when asked for a password, use a Hugging Face access token with "write" scope:
#   https://huggingface.co/settings/tokens
git add -A
git commit -m "SWP'sGift: AI + plagiarism checker"
git push
```

The build takes 2–4 minutes (installing `fastapi`, `pypdf`, `numpy`, etc.). When the status turns
green, your site is live.

**Sanity check after it boots:** open `/healthz` — it should return `{"ok":true,"version":"1.0.0"}`.

---

## Step 3 — Turn on Google web checking (3 minutes)

The site works without this; the header badge just reads *web off*.

1. **Enable the API.** Open
   <https://console.cloud.google.com/apis/library/customsearch.googleapis.com> → **Enable**.
   (Create a project first if asked.)
2. **Get an API key.** <https://console.cloud.google.com/apis/credentials> →
   **Create credentials** → **API key** → copy it. Optionally restrict it to *Custom Search API*.
3. **Create the search engine.** <https://programmablesearchengine.google.com/controlpanel/create>
   - Name: `SWP'sGift`
   - **What to search: `Search the entire web`** ← important, the default only searches one site
   - Create, then copy the **Search engine ID (cx)**.
4. **Add both to the Space.** Space → **Settings** → **Variables and secrets** → **New secret**:

   | Name | Value |
   |---|---|
   | `GOOGLE_API_KEY` | your API key |
   | `GOOGLE_CSE_ID` | your search engine ID (`cx`) |

5. The Space restarts automatically. The header badge changes to **web on** and the *"Search the
   public web"* checkbox becomes usable.

**Quota:** the free tier allows **100 queries per day** for the whole project. Each document check
uses up to 8 searches (`WEB_MAX_QUERIES`, adjustable as another secret), so roughly 12 checks a day
with web on. When the quota runs out the report says so explicitly instead of silently returning
nothing. For heavier use, enable billing on the Google project or add a `SERPAPI_KEY` instead.

---

## Step 4 — Put the code on GitHub (2 minutes)

Keeps the project backed up and lets you deploy elsewhere later (Render, Fly, a college server).

```bash
cd sentinel-check
git init
git add .
git commit -m "SWP'sGift — AI and plagiarism checker"
git branch -M main
git remote add origin https://github.com/<your-username>/swpsgift.git   # create the empty repo first
git push -u origin main
```

`.gitignore` already excludes `data/`, so no uploads or API keys ever reach the repo. The
`render.yaml` in the repo lets you deploy the same code to Render with **New → Blueprint** if you
ever want a second URL.

---

## What the free tier does to your data

Hugging Face Spaces (free) gives you a container with **ephemeral** disk. In practice:

- The **reference library resets to empty** whenever the Space is rebuilt or restarted.
- Individual reports stay available until the container restarts.
- The free Space also **sleeps after ~48 hours** of no traffic and wakes on the next visit (a few
  seconds of cold start).

If you need the library to persist, the cheapest honest options are:

- Hugging Face **persistent storage** upgrade (~$5/month), or
- a free **Neon / Supabase Postgres** instance, swapping the four-table SQLite layer in
  `app/store.py` (contained change, I can do it if you want), or
- run the Docker image on your own machine or college server with a mounted volume:

  ```bash
  docker build -t swpsgift .
  docker run -d -p 80:7860 -v /srv/swpsgift:/data --name swpsgift swpsgift
  ```

---

## Environment variables reference

| Variable | Required | Purpose |
|---|---|---|
| `GOOGLE_API_KEY` | for web check | Google Cloud API key |
| `GOOGLE_CSE_ID` | for web check | Programmable Search engine ID (`cx`) |
| `SERPAPI_KEY` | alternative | SerpAPI key, used instead of Google if set |
| `WEB_MAX_QUERIES` | optional | Searches per document (default 8) |
| `DATA_DIR` | optional | Storage location (default `/data` in Docker) |
| `PORT` | optional | Defaults to 7860 in the container |

---

## Pre-flight checklist

- [x] `Dockerfile` listens on `0.0.0.0:7860` and runs as UID 1000 (Spaces requirement)
- [x] `app_port: 7860` in the Space `README.md` front matter
- [x] `/healthz` endpoint for platform health checks
- [x] 25 MB limit enforced server-side (returns `413`), not just in the browser
- [x] No word limit; documents are processed as background jobs with live progress
- [x] `data/` and all keys excluded from git
- [x] Web checking degrades gracefully and reports quota errors in plain language

If a build fails, send me the build log — the usual causes are a missing `README.md` front matter
block or uploading the folder instead of its contents.
