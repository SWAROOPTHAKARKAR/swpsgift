"""SWP'sGift -- AI-text and plagiarism checker website.

FastAPI application: upload (25 MB per file, unlimited word count), background
analysis jobs, live progress, downloadable reports, and a reference library that
acts as the plagiarism corpus.
"""
from __future__ import annotations

import html
import os
import shutil
import tempfile
import time
import uuid
from concurrent.futures import ThreadPoolExecutor

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse

from . import ai_detect, plagiarism, store
from .extract import ExtractionError, extract

MAX_UPLOAD = 25 * 1024 * 1024          # 25 MB per file
CHUNK = 1024 * 256
APP_VERSION = "1.0.0"

APP_NAME = "SWP'sGift"

app = FastAPI(title=APP_NAME, version=APP_VERSION, docs_url="/api/docs")
executor = ThreadPoolExecutor(max_workers=3, thread_name_prefix="analysis")

store.init()


@app.on_event("startup")
def _startup() -> None:
    # fingerprint any corpus documents that were added before a restart
    for doc in store.corpus():
        if not store.has_fingerprints(doc["id"]):
            try:
                text = store.load_text(doc["id"])
                if text:
                    store.save_fingerprints(doc["id"], plagiarism.digest(text))
            except Exception:
                pass


# --------------------------------------------------------------------------- helpers
def _save_upload(upload: UploadFile) -> tuple[str, int]:
    """Stream an upload to a temp file, enforcing the 25 MB ceiling."""
    suffix = os.path.splitext(upload.filename or "upload")[1] or ".bin"
    fd, path = tempfile.mkstemp(suffix=suffix)
    size = 0
    try:
        with os.fdopen(fd, "wb") as out:
            while True:
                chunk = upload.file.read(CHUNK)
                if not chunk:
                    break
                size += len(chunk)
                if size > MAX_UPLOAD:
                    raise HTTPException(
                        status_code=413,
                        detail=f"File exceeds the {MAX_UPLOAD // (1024*1024)} MB per-file limit.")
                out.write(chunk)
    except HTTPException:
        os.unlink(path)
        raise
    except Exception as exc:
        os.unlink(path)
        raise HTTPException(status_code=400, detail=f"Upload failed: {exc}")
    return path, size


def _run_job(job_id: str, path: str, filename: str, mode: str,
             add_corpus: bool, do_web: bool) -> None:
    started = time.time()
    try:
        store.update_job(job_id, status="running", progress=4, stage="Reading file")
        with open(path, "rb") as f:
            data = f.read()
        text, meta = extract(data, filename)
        words = len(text.split())
        store.update_job(job_id, words=words, progress=10, stage="Indexing document")

        doc_id = store.add_document(filename, text, meta, in_corpus=add_corpus,
                                    size=len(data))
        if add_corpus:
            store.save_fingerprints(doc_id, plagiarism.digest(text))
        store.update_job(job_id, doc_id=doc_id)

        result = {
            "job_id": job_id,
            "file": filename,
            "size_bytes": len(data),
            "words": words,
            "characters": len(text),
            "meta": meta,
            "mode": mode,
            "added_to_library": bool(add_corpus),
            "created_at": time.time(),
            "engine": {"version": APP_VERSION, "k_shingle": plagiarism.K},
        }

        if mode in ("ai", "both"):
            store.update_job(job_id, progress=18, stage="Measuring writing style")
            result["ai"] = ai_detect.analyze(text)

        if mode in ("plag", "both"):
            def progress(pct: int, stage: str) -> None:
                store.update_job(job_id, progress=max(20, min(96, pct)), stage=stage)

            progress(22, "Loading library")
            corpus_docs = [d for d in store.corpus() if d["id"] != doc_id]
            result["plagiarism"] = plagiarism.analyze(
                text, corpus_docs, store.load_fingerprints, store.load_text,
                progress, do_web)

        result["elapsed_seconds"] = round(time.time() - started, 2)
        store.save_result(job_id, result)
        store.update_job(job_id, status="done", progress=100, stage="Complete")
        store.prune_jobs()
    except ExtractionError as exc:
        store.update_job(job_id, status="error", error=str(exc), stage="Failed")
    except HTTPException as exc:
        store.update_job(job_id, status="error", error=str(exc.detail), stage="Failed")
    except Exception as exc:  # keep the worker alive, surface the message
        store.update_job(job_id, status="error",
                         error=f"{type(exc).__name__}: {exc}", stage="Failed")
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


# --------------------------------------------------------------------------- meta
@app.get("/healthz")
def healthz():
    return {"ok": True, "version": APP_VERSION}


@app.get("/api/meta")
def meta():
    stats = store.corpus_stats()
    return {
        "version": APP_VERSION,
        "max_upload_mb": MAX_UPLOAD // (1024 * 1024),
        "word_limit": None,
        "corpus": stats,
        "web": plagiarism.web_status(),
        "accepted": ["pdf", "docx", "pptx", "xlsx", "txt", "md", "csv", "rtf", "html"],
    }


# --------------------------------------------------------------------------- checks
@app.post("/api/check")
async def check(file: UploadFile | None = File(default=None),
                text: str = Form(default=""),
                mode: str = Form(default="both"),
                add_to_library: bool = Form(default=False),
                web_search: bool = Form(default=False)):
    if mode not in ("ai", "plag", "both"):
        raise HTTPException(400, "mode must be ai, plag or both")

    if file is not None and file.filename:
        path, size = _save_upload(file)
        filename = file.filename
        if size == 0:
            os.unlink(path)
            raise HTTPException(400, "The uploaded file is empty.")
    elif text.strip():
        if len(text.encode("utf-8")) > MAX_UPLOAD:
            raise HTTPException(413, "Pasted text exceeds the 25 MB limit.")
        fd, path = tempfile.mkstemp(suffix=".txt")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
        filename = "pasted-text.txt"
    else:
        raise HTTPException(400, "Provide a file or paste some text.")

    job_id = uuid.uuid4().hex[:16]
    store.create_job(job_id, filename, mode, words=0, doc_id=None)
    executor.submit(_run_job, job_id, path, filename, mode, add_to_library, web_search)
    return {"job_id": job_id}


@app.get("/api/job/{job_id}")
def job(job_id: str):
    job_row = store.get_job(job_id)
    if not job_row:
        raise HTTPException(404, "Unknown job")
    payload = {k: job_row[k] for k in
               ("id", "filename", "mode", "status", "progress", "stage", "words", "error")}
    if job_row["status"] == "done" and job_row.get("result"):
        result = dict(job_row["result"])
        # sentence/offset detail is served by /text + included here, but the raw
        # body is large so it is trimmed from the poll response
        payload["result"] = result
    return JSONResponse(payload)


@app.get("/api/job/{job_id}/text", response_class=PlainTextResponse)
def job_text(job_id: str):
    job_row = store.get_job(job_id)
    if not job_row or not job_row.get("doc_id"):
        raise HTTPException(404, "No text for this job")
    return store.load_text(job_row["doc_id"])


@app.get("/api/jobs")
def jobs():
    return {"jobs": store.recent_jobs(30)}


# --------------------------------------------------------------------------- corpus
@app.get("/api/corpus")
def corpus_list():
    return {"documents": store.corpus(), "stats": store.corpus_stats()}


@app.post("/api/corpus/upload")
async def corpus_upload(files: list[UploadFile] = File(default=[])):
    added, errors = [], []
    for upload in files:
        try:
            path, size = _save_upload(upload)
            with open(path, "rb") as f:
                data = f.read()
            text, meta = extract(data, upload.filename or "reference")
            doc_id = store.add_document(upload.filename or "reference", text, meta,
                                        in_corpus=True, size=len(data))
            store.save_fingerprints(doc_id, plagiarism.digest(text))
            added.append({"id": doc_id, "name": upload.filename,
                          "words": len(text.split())})
        except ExtractionError as exc:
            errors.append({"file": upload.filename, "error": str(exc)})
        except HTTPException as exc:
            errors.append({"file": upload.filename, "error": exc.detail})
        finally:
            try:
                os.unlink(path)
            except Exception:
                pass
    return {"added": added, "errors": errors, "stats": store.corpus_stats()}


@app.delete("/api/corpus/{doc_id}")
def corpus_delete(doc_id: int):
    if not store.delete_document(doc_id):
        raise HTTPException(404, "Document not found")
    return {"deleted": doc_id, "stats": store.corpus_stats()}


# --------------------------------------------------------------------------- report
def _ring(pct: float, colour: str, label: str) -> str:
    pct = max(0.0, min(100.0, float(pct or 0)))
    r, circ = 54, 2 * 3.14159 * 54
    dash = circ * pct / 100.0
    return f"""
    <div class="ring">
      <svg viewBox="0 0 140 140" width="140" height="140">
        <circle cx="70" cy="70" r="{r}" fill="none" stroke="#e6eaf2" stroke-width="14"/>
        <circle cx="70" cy="70" r="{r}" fill="none" stroke="{colour}" stroke-width="14"
                stroke-linecap="round" stroke-dasharray="{dash:.1f} {circ:.1f}"
                transform="rotate(-90 70 70)"/>
        <text x="70" y="66" text-anchor="middle" font-size="26" font-weight="700"
              fill="#12203a" font-family="Georgia, serif">{pct:.1f}%</text>
        <text x="70" y="88" text-anchor="middle" font-size="11" fill="#6b7280"
              font-family="Helvetica, Arial, sans-serif">{html.escape(label)}</text>
      </svg>
    </div>"""


@app.get("/api/report/{job_id}", response_class=HTMLResponse)
def report(job_id: str):
    job_row = store.get_job(job_id)
    if not job_row:
        raise HTTPException(404, "Unknown job")
    if job_row["status"] != "done" or not job_row.get("result"):
        raise HTTPException(409, f"Job is {job_row['status']}, no report yet.")
    r = job_row["result"]
    ai = r.get("ai") or {}
    pl = r.get("plagiarism") or {}
    esc = html.escape

    ai_rows = ""
    if ai.get("available"):
        m = ai["metrics"]
        labels = [
            ("Average sentence length", f"{m['avg_sentence_words']} words"),
            ("Sentence-length variation (std)", f"{m['sentence_length_std']} words"),
            ("Burstiness", m["burstiness"]),
            ("Length uniformity", f"{m['length_uniformity'] * 100:.0f}%"),
            ("Formulaic phrases / 100 words", m["cliche_per_100w"]),
            ("Transition words / 100 words", m["transition_per_100w"]),
            ("Contractions / 100 words", m["contraction_per_100w"]),
            ("First-person markers / 100 words", m["first_person_per_100w"]),
            ("Punctuation variety / 100 words", m["punctuation_per_100w"]),
            ("Lexical diversity (MSTTR)", m["lexical_diversity"]),
            ("Word entropy", f"{m['entropy_bits']} bits"),
        ]
        ai_rows = "".join(f"<tr><td>{esc(k)}</td><td>{esc(str(v))}</td></tr>"
                          for k, v in labels)

    flagged = ""
    if ai.get("available"):
        flagged = "".join(
            f"<li><span class='pill'>{p['score']:.0f}%</span> {esc(p.get('preview',''))}</li>"
            for p in ai.get("evidence", []))

    src_rows = "".join(
        f"<tr><td>{esc(s['name'])}</td><td>{s['matched_words']}</td>"
        f"<td>{s['pct_of_submission']:.2f}%</td><td>{s['passage_count']}</td></tr>"
        for s in pl.get("sources", [])) or "<tr><td colspan='4'>No matching passages found in the library.</td></tr>"

    passages = ""
    for m in pl.get("matches", [])[:15]:
        passages += f"""
        <div class="match">
          <div class="match-head">{esc(m.get('source',''))} &middot; {m['words']} words matched</div>
          <div class="cols">
            <div><h4>Submitted text</h4><p>{esc(m['text'][:700])}</p></div>
            <div><h4>Library source</h4><p>{esc(m['source_excerpt'][:700])}</p></div>
          </div>
        </div>"""

    web = pl.get("web") or {}
    if web.get("enabled"):
        web_html = "".join(
            f"<li><b>{esc(w['title'])}</b> ({w['similarity']}%) — "
            f"<a href='{esc(w['url'])}'>{esc(w['url'])}</a><br><span class='muted'>{esc(w['snippet'][:240])}</span></li>"
            for w in web.get("matches", [])) or "<li>No close web matches found.</li>"
    else:
        web_html = f"<li class='muted'>{esc(web.get('reason','Web search not configured.'))}</li>"

    def block(title, body):
        return f"<section><h2>{esc(title)}</h2>{body}</section>"

    ai_section = ""
    if ai.get("available"):
        ai_section = block("AI-text analysis", f"""
        <div class="score-row">
          {_ring(ai['score'], '#2f6df6', 'AI-like score')}
          <div>
            <p class="verdict">{esc(ai['verdict'])}</p>
            <p class="muted">{ai['sentences']} sentences analysed across {ai['words']} words.
            This is a stylometric estimate, not proof of authorship.</p>
          </div>
        </div>
        <table class="grid"><tr><th>Signal</th><th>Measured value</th></tr>{ai_rows}</table>
        <h3>Most AI-typical passages</h3><ul class="flagged">{flagged}</ul>""")
    elif ai:
        ai_section = block("AI-text analysis", f"<p>{esc(ai.get('message',''))}</p>")

    pl_section = ""
    if pl:
        pl_section = block("Plagiarism analysis", f"""
        <div class="score-row">
          {_ring(pl.get('coverage_pct', 0), '#d1495b', 'Text matched')}
          <div>
            <p class="verdict">{esc(pl.get('verdict',''))}</p>
            <p class="muted">{pl.get('matched_tokens',0)} of {pl.get('words',0)} words matched
            against {pl.get('corpus_size',0)} library documents.</p>
          </div>
        </div>
        <table class="grid"><tr><th>Library document</th><th>Matched words</th>
        <th>% of submission</th><th>Passages</th></tr>{src_rows}</table>
        <h3>Matched passages</h3>{passages or '<p class="muted">No passages above the reporting threshold.</p>'}
        <h3>Web check</h3><ul>{web_html}</ul>""")

    body = f"""
    <header>
      <div class="brand">SWP'sGift <span>· document report</span></div>
      <div class="muted">Generated {time.strftime('%d %b %Y, %H:%M')} &middot; job {esc(job_id)}</div>
    </header>
    <h1>{esc(r['file'])}</h1>
    <p class="muted">{r['words']:,} words &middot; {r['characters']:,} characters &middot;
      {r['size_bytes']/1024/1024:.2f} MB &middot; analysed in {r.get('elapsed_seconds',0)}s</p>
    {ai_section}
    {pl_section}
    <section>
      <h2>How to read this report</h2>
      <p>The AI score is produced by stylometric analysis — burstiness, sentence-length
      uniformity, formulaic-phrase density, transition loading, contraction use,
      punctuation variety, lexical diversity and template repetition. It estimates how
      closely the writing resembles machine-generated prose. It cannot prove that a
      document was written by a person or by a model, and short texts are inherently
      unreliable.</p>
      <p>Plagiarism figures report exact n-gram overlap with the documents in your
      library plus, when enabled, public web pages. Paraphrased text that shares no
      8-word sequence will not be flagged, and absence of matches is not proof of
      originality — add relevant sources to the library and enable web search for
      meaningful coverage.</p>
    </section>"""

    return HTMLResponse(f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SWP'sGift report — {esc(r['file'])}</title>
    <style>
      :root {{ --ink:#12203a; --muted:#6b7280; --line:#e3e8f0; }}
      * {{ box-sizing:border-box; }}
      body {{ margin:0; padding:38px 28px 60px; font:15px/1.65 Georgia,'Times New Roman',serif;
        color:var(--ink); background:#fff; max-width:900px; margin-inline:auto; }}
      header {{ display:flex; justify-content:space-between; align-items:baseline;
        border-bottom:2px solid var(--ink); padding-bottom:10px; margin-bottom:26px; }}
      .brand {{ font:700 19px/1 Helvetica,Arial,sans-serif; letter-spacing:.02em; }}
      .brand span {{ color:var(--muted); font-weight:400; }}
      h1 {{ font-size:26px; margin:0 0 6px; }}
      h2 {{ font:700 13px/1.3 Helvetica,Arial,sans-serif; text-transform:uppercase;
        letter-spacing:.08em; color:#2f6df6; margin:34px 0 12px; }}
      h3 {{ font:700 14px/1.4 Helvetica,Arial,sans-serif; margin:22px 0 8px; }}
      h4 {{ font:600 11px/1.4 Helvetica,Arial,sans-serif; text-transform:uppercase;
        letter-spacing:.06em; color:var(--muted); margin:0 0 4px; }}
      .muted {{ color:var(--muted); font-size:13px; }}
      .score-row {{ display:flex; gap:26px; align-items:center; }}
      .verdict {{ font:700 20px/1.3 Helvetica,Arial,sans-serif; margin:0 0 4px; }}
      table.grid {{ width:100%; border-collapse:collapse; margin:14px 0; font-size:13.5px; }}
      table.grid th, table.grid td {{ text-align:left; padding:7px 10px; border-bottom:1px solid var(--line); }}
      table.grid th {{ font:600 11px/1.4 Helvetica,Arial,sans-serif; text-transform:uppercase;
        letter-spacing:.06em; color:var(--muted); }}
      ul {{ padding-left:20px; }} ul.flagged li {{ margin-bottom:10px; }}
      .pill {{ display:inline-block; min-width:44px; text-align:center; background:#eef2ff;
        color:#2f4bd6; border-radius:20px; padding:1px 8px; font:600 11px/1.7 Helvetica,Arial,sans-serif; }}
      .match {{ border:1px solid var(--line); border-radius:10px; padding:12px 14px; margin-bottom:14px; }}
      .match-head {{ font:600 12px/1.4 Helvetica,Arial,sans-serif; color:#d1495b; margin-bottom:8px; }}
      .cols {{ display:grid; grid-template-columns:1fr 1fr; gap:16px; }}
      .cols p {{ margin:0; font-size:13px; background:#f8fafc; padding:8px 10px; border-radius:6px; }}
      @media print {{ body {{ padding:0; }} .match {{ break-inside:avoid; }} }}
    </style></head><body>{body}
    <p class="muted" style="margin-top:40px;border-top:1px solid var(--line);padding-top:12px">
      SWP'sGift {APP_VERSION} &middot; automated estimate for review support, not a
      disciplinary finding.</p></body></html>""")


# --------------------------------------------------------------------------- website
SITE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "site")

PAGES = {
    "home": {
        "file": "home.html",
        "title": "SWP'sGift — free AI & plagiarism checker, no word limit",
        "description": ("Check any document for AI-generated writing and copied text. "
                        "Sentence-level AI scoring, plagiarism matching against your own "
                        "library, 25 MB per file, no word limit, free."),
    },
    "check": {
        "file": "check.html",
        "title": "Check a document · SWP'sGift",
        "description": ("Upload a PDF, DOCX or paste text to get an AI-likeness score and a "
                        "plagiarism report. 25 MB per file, no word limit."),
    },
    "library": {
        "file": "library.html",
        "title": "Reference library · SWP'sGift",
        "description": "Add reference documents so plagiarism checks have something to compare against.",
    },
    "how": {
        "file": "how.html",
        "title": "How it works · SWP'sGift",
        "description": ("The exact stylometric signals behind the AI score, the n-gram method "
                        "behind plagiarism matching, and the limits of both."),
    },
}


def _render(page: str) -> HTMLResponse:
    meta = PAGES[page]
    with open(os.path.join(SITE, "base.html"), encoding="utf-8") as f:
        out = f.read()
    with open(os.path.join(SITE, meta["file"]), encoding="utf-8") as f:
        content = f.read()
    out = (out.replace("{{title}}", meta["title"])
              .replace("{{description}}", meta["description"])
              .replace("{{content}}", content)
              .replace("{{scripts}}", ""))
    for key in ("home", "check", "library", "how"):
        out = out.replace("{{nav_%s}}" % key, "on" if key == page else "")
    return HTMLResponse(out)


@app.get("/", response_class=HTMLResponse)
def page_home():
    return _render("home")


@app.get("/check", response_class=HTMLResponse)
def page_check():
    return _render("check")


@app.get("/library", response_class=HTMLResponse)
def page_library():
    return _render("library")


@app.get("/how-it-works", response_class=HTMLResponse)
def page_how():
    return _render("how")


@app.get("/robots.txt", response_class=PlainTextResponse)
def robots():
    return "User-agent: *\nAllow: /\n"


@app.get("/favicon.ico")
def favicon():
    return PlainTextResponse("", status_code=204)
