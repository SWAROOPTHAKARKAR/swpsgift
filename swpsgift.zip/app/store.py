"""SQLite metadata store + on-disk artifacts (text, fingerprints, job results)."""
from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import threading
import time
from collections import OrderedDict

import numpy as np

_default_base = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
BASE = os.environ.get("DATA_DIR", _default_base)
try:  # if the configured directory is not writable, fall back instead of crashing
    os.makedirs(BASE, exist_ok=True)
except OSError:
    BASE = _default_base
DOCS = os.path.join(BASE, "docs")
FPS = os.path.join(BASE, "fp")
JOBS = os.path.join(BASE, "jobs")
DB = os.path.join(BASE, "app.db")

for d in (BASE, DOCS, FPS, JOBS):
    os.makedirs(d, exist_ok=True)

_lock = threading.Lock()
_fp_cache: "OrderedDict[int, np.ndarray]" = OrderedDict()
FP_CACHE_MAX = 24


def conn() -> sqlite3.Connection:
    c = sqlite3.connect(DB, timeout=30, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA synchronous=NORMAL")
    return c


def init() -> None:
    with _lock, conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            sha TEXT,
            size INTEGER,
            words INTEGER,
            chars INTEGER,
            meta TEXT,
            in_corpus INTEGER DEFAULT 0,
            created_at REAL
        );
        CREATE TABLE IF NOT EXISTS jobs (
            id TEXT PRIMARY KEY,
            created_at REAL,
            filename TEXT,
            mode TEXT,
            status TEXT,
            progress INTEGER DEFAULT 0,
            stage TEXT,
            words INTEGER,
            error TEXT,
            doc_id INTEGER
        );
        CREATE INDEX IF NOT EXISTS idx_documents_corpus ON documents(in_corpus);
        CREATE INDEX IF NOT EXISTS idx_jobs_created ON jobs(created_at DESC);
        """)


def add_document(name: str, text: str, meta: dict, in_corpus: bool = False,
                 size: int | None = None) -> int:
    sha = hashlib.sha256(text.encode("utf-8", "replace")).hexdigest()
    with _lock, conn() as c:
        if in_corpus:
            row = c.execute("SELECT id FROM documents WHERE sha=? AND in_corpus=1",
                            (sha,)).fetchone()
            if row:
                return int(row["id"])
        cur = c.execute(
            "INSERT INTO documents (name, sha, size, words, chars, meta, in_corpus, created_at)"
            " VALUES (?,?,?,?,?,?,?,?)",
            (name[:200], sha, size or len(text.encode("utf-8", "replace")),
             len(text.split()), len(text), json.dumps(meta), 1 if in_corpus else 0,
             time.time()),
        )
        doc_id = int(cur.lastrowid)
    with open(os.path.join(DOCS, f"{doc_id}.txt"), "w", encoding="utf-8") as f:
        f.write(text)
    return doc_id


def save_fingerprints(doc_id: int, fps: np.ndarray) -> None:
    np.save(os.path.join(FPS, f"{doc_id}.npy"), fps)
    with _lock:
        _fp_cache[doc_id] = fps
        _fp_cache.move_to_end(doc_id)
        while len(_fp_cache) > FP_CACHE_MAX:
            _fp_cache.popitem(last=False)


def load_fingerprints(doc_id: int) -> np.ndarray:
    with _lock:
        if doc_id in _fp_cache:
            _fp_cache.move_to_end(doc_id)
            return _fp_cache[doc_id]
    path = os.path.join(FPS, f"{doc_id}.npy")
    if not os.path.exists(path):
        return np.empty(0, dtype=np.uint64)
    arr = np.load(path)
    with _lock:
        _fp_cache[doc_id] = arr
        _fp_cache.move_to_end(doc_id)
        while len(_fp_cache) > FP_CACHE_MAX:
            _fp_cache.popitem(last=False)
    return arr


def load_text(doc_id: int) -> str:
    path = os.path.join(DOCS, f"{doc_id}.txt")
    if not os.path.exists(path):
        return ""
    with open(path, encoding="utf-8", errors="replace") as f:
        return f.read()


def has_fingerprints(doc_id: int) -> bool:
    return os.path.exists(os.path.join(FPS, f"{doc_id}.npy"))


def corpus() -> list[dict]:
    with conn() as c:
        rows = c.execute(
            "SELECT id, name, words, created_at FROM documents WHERE in_corpus=1"
            " ORDER BY created_at DESC").fetchall()
    return [dict(r) for r in rows]


def corpus_stats() -> dict:
    with conn() as c:
        row = c.execute(
            "SELECT COUNT(*) n, COALESCE(SUM(words),0) w FROM documents WHERE in_corpus=1"
        ).fetchone()
    return {"documents": int(row["n"]), "words": int(row["w"])}


def all_documents() -> list[dict]:
    with conn() as c:
        rows = c.execute(
            "SELECT id, name, words, chars, in_corpus, created_at FROM documents"
            " ORDER BY created_at DESC LIMIT 200").fetchall()
    return [dict(r) for r in rows]


def delete_document(doc_id: int) -> bool:
    with _lock, conn() as c:
        cur = c.execute("DELETE FROM documents WHERE id=?", (doc_id,))
        removed = cur.rowcount > 0
    for path in (os.path.join(DOCS, f"{doc_id}.txt"), os.path.join(FPS, f"{doc_id}.npy")):
        if os.path.exists(path):
            try:
                os.remove(path)
            except OSError:
                pass
    with _lock:
        _fp_cache.pop(doc_id, None)
    return removed


# ------------------------------------------------------------------ jobs
def create_job(job_id: str, filename: str, mode: str, words: int, doc_id: int | None) -> None:
    with _lock, conn() as c:
        c.execute(
            "INSERT INTO jobs (id, created_at, filename, mode, status, progress, stage, words, doc_id)"
            " VALUES (?,?,?,?,?,?,?,?,?)",
            (job_id, time.time(), filename[:200], mode, "queued", 0, "Queued", words, doc_id))


def update_job(job_id: str, **fields) -> None:
    if not fields:
        return
    cols = ", ".join(f"{k}=?" for k in fields)
    with _lock, conn() as c:
        c.execute(f"UPDATE jobs SET {cols} WHERE id=?", (*fields.values(), job_id))


def get_job(job_id: str) -> dict | None:
    with conn() as c:
        row = c.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
    if not row:
        return None
    job = dict(row)
    result_path = os.path.join(JOBS, f"{job_id}.json")
    if os.path.exists(result_path):
        try:
            with open(result_path, encoding="utf-8") as f:
                job["result"] = json.load(f)
        except Exception:
            job["result"] = None
    return job


def save_result(job_id: str, result: dict) -> None:
    tmp = os.path.join(JOBS, f"{job_id}.json.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(result, f)
    os.replace(tmp, os.path.join(JOBS, f"{job_id}.json"))


def recent_jobs(limit: int = 25) -> list[dict]:
    with conn() as c:
        rows = c.execute(
            "SELECT id, created_at, filename, mode, status, words FROM jobs"
            " ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in rows]


def prune_jobs(keep: int = 300) -> None:
    with _lock, conn() as c:
        rows = c.execute("SELECT id FROM jobs ORDER BY created_at DESC LIMIT -1 OFFSET ?",
                         (keep,)).fetchall()
        for r in rows:
            c.execute("DELETE FROM jobs WHERE id=?", (r["id"],))
            path = os.path.join(JOBS, f"{r['id']}.json")
            if os.path.exists(path):
                try:
                    os.remove(path)
                except OSError:
                    pass
