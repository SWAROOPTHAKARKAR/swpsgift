"""Text extraction for uploaded documents.

Supported: .txt .md .csv .log .rtf(loose) .pdf .docx .xlsx .pptx(loose) .html
Returns plain text plus a small metadata dict.
"""
from __future__ import annotations

import io
import re
import zipfile


class ExtractionError(Exception):
    pass


def _clean(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = text.replace("\u00a0", " ").replace("\ufeff", "")
    text = re.sub(r"[ \t]+\n", "\n", text)
    text = re.sub(r"\n{4,}", "\n\n\n", text)
    return text.strip()


def _pdf(data: bytes) -> tuple[str, dict]:
    from pypdf import PdfReader

    reader = PdfReader(io.BytesIO(data))
    pages = []
    for page in reader.pages:
        try:
            pages.append(page.extract_text() or "")
        except Exception:
            pages.append("")
    text = "\n\n".join(pages)
    meta = {"pages": len(reader.pages)}
    if not text.strip():
        raise ExtractionError(
            "No text layer found in this PDF. It is probably a scan — run OCR "
            "(e.g. ocrmypdf) and upload again."
        )
    return text, meta


def _docx(data: bytes) -> tuple[str, dict]:
    import docx

    document = docx.Document(io.BytesIO(data))
    chunks = [p.text for p in document.paragraphs]
    for table in document.tables:
        for row in table.rows:
            cells = [c.text.strip() for c in row.cells]
            if any(cells):
                chunks.append(" | ".join(cells))
    meta = {"paragraphs": len(document.paragraphs), "tables": len(document.tables)}
    return "\n".join(chunks), meta


def _pptx(data: bytes) -> tuple[str, dict]:
    from pptx import Presentation

    prs = Presentation(io.BytesIO(data))
    out = []
    for i, slide in enumerate(prs.slides, 1):
        parts = []
        for shape in slide.shapes:
            if shape.has_text_frame:
                parts.append(shape.text_frame.text)
        if parts:
            out.append(f"[Slide {i}] " + " ".join(parts))
    return "\n\n".join(out), {"slides": len(prs.slides)}


def _xlsx(data: bytes) -> tuple[str, dict]:
    import openpyxl

    wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    lines = []
    for ws in wb.worksheets:
        lines.append(f"[Sheet: {ws.title}]")
        for row in ws.iter_rows(values_only=True):
            cells = [str(c) for c in row if c is not None]
            if cells:
                lines.append(" | ".join(cells))
    return "\n".join(lines), {"sheets": len(wb.worksheets)}


def _html(data: bytes) -> tuple[str, dict]:
    raw = data.decode("utf-8", errors="replace")
    raw = re.sub(r"(?is)<(script|style)[^>]*>.*?</\1>", " ", raw)
    raw = re.sub(r"(?i)<br\s*/?>", "\n", raw)
    raw = re.sub(r"(?i)</(p|div|h[1-6]|li|tr)>", "\n", raw)
    text = re.sub(r"<[^>]+>", " ", raw)
    import html as htmlmod

    return htmlmod.unescape(text), {}


def _rtf(data: bytes) -> tuple[str, dict]:
    raw = data.decode("latin-1", errors="replace")
    raw = re.sub(r"\\'([0-9a-f]{2})", lambda m: chr(int(m.group(1), 16)), raw)
    raw = re.sub(r"\\[a-z]+-?\d* ?", " ", raw)
    raw = raw.replace("{", " ").replace("}", " ")
    return raw, {}


def extract(data: bytes, filename: str) -> tuple[str, dict]:
    """Return (text, metadata). Raises ExtractionError on unsupported/failed input."""
    name = (filename or "").lower()
    ext = name.rsplit(".", 1)[-1] if "." in name else ""

    handlers = {
        "pdf": _pdf,
        "docx": _docx,
        "docm": _docx,
        "pptx": _pptx,
        "xlsx": _xlsx,
        "xlsm": _xlsx,
        "html": _html,
        "htm": _html,
        "rtf": _rtf,
    }

    try:
        if ext in handlers:
            text, meta = handlers[ext](data)
        elif ext in ("txt", "md", "markdown", "csv", "log", "tex", "json", "py", "js", "java", "c", "cpp", "tsv"):
            text, meta = data.decode("utf-8", errors="replace"), {}
        elif ext == "doc":
            raise ExtractionError(
                "Legacy .doc files are not supported. Save the file as .docx "
                "(or PDF) and upload again."
            )
        else:
            # last resort: try utf-8, then give up
            try:
                text, meta = data.decode("utf-8"), {}
            except UnicodeDecodeError:
                raise ExtractionError(
                    f"Unsupported file type '.{ext}'. Upload PDF, DOCX, PPTX, XLSX, "
                    "TXT, MD, CSV, HTML or RTF."
                )
    except ExtractionError:
        raise
    except Exception as exc:  # corrupt file, encrypted pdf, etc.
        raise ExtractionError(f"Could not read this file ({type(exc).__name__}: {exc}).")

    text = _clean(text)
    if not text:
        raise ExtractionError("The file contains no readable text.")
    meta["characters"] = len(text)
    meta["words"] = len(text.split())
    return text, meta
