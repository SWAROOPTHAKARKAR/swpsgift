"""Explainable AI-text detector.

The engine is a stylometric classifier, not a black box. It measures the signals
that AI-detection tools normally rely on -- sentence-length burstiness, cliche
density, transition-word loading, punctuation variety, contraction use,
lexical diversity and template repetition -- and combines them into a 0-100
score per sentence, per paragraph and for the document as a whole.

No pretrained language model is required, so the service starts instantly and
runs inside a 512 MB free-tier container.
"""
from __future__ import annotations

import math
import re
from collections import Counter

# --------------------------------------------------------------------------- data
AI_PHRASES = [
    "it is important to note", "it is worth noting", "it should be noted",
    "in today's fast-paced", "in today's digital", "in the ever-evolving",
    "in the realm of", "in the world of", "navigating the complexities",
    "plays a crucial role", "plays a vital role", "plays a pivotal role",
    "plays a significant role", "a testament to", "underscores the importance",
    "serves as a", "stands as a", "delve into", "delving into",
    "the landscape of", "the ever-changing landscape", "a holistic approach",
    "a comprehensive understanding", "robust and scalable", "seamless integration",
    "leverage the power", "harness the power", "in conclusion", "in summary",
    "to sum up", "furthermore", "moreover", "additionally",
    "not only", "but also", "on the other hand", "as such",
    "it is essential to", "it is crucial to", "one of the most important",
    "a wide range of", "a variety of factors", "various aspects",
    "multifaceted", "paradigm shift", "cutting-edge", "state-of-the-art",
    "game-changer", "revolutionize", "transformative potential",
    "in the context of", "when it comes to", "the fact that",
    "crucial", "pivotal", "comprehensive", "meticulous", "intricate",
    "foster", "facilitate", "utilize", "endeavor", "furthermore",
]

TRANSITIONS = {
    "moreover", "furthermore", "additionally", "however", "therefore",
    "consequently", "thus", "hence", "nevertheless", "nonetheless",
    "overall", "firstly", "secondly", "thirdly", "finally", "in conclusion",
    "in summary", "similarly", "likewise", "conversely", "subsequently",
    "accordingly", "notably", "particularly", "specifically", "ultimately",
}

CONTRACTIONS = {
    "don't", "doesn't", "didn't", "isn't", "aren't", "wasn't", "weren't",
    "can't", "couldn't", "won't", "wouldn't", "shouldn't", "it's", "that's",
    "there's", "here's", "i'm", "i've", "we're", "we've", "they're", "you're",
    "let's", "hasn't", "haven't", "ain't",
}

FIRST_PERSON = {"i", "we", "my", "our", "us", "me", "mine", "ours", "i'm",
                "we're", "i've", "we've", "i'd", "we'd", "myself", "ourselves"}

HEDGES = {"maybe", "perhaps", "probably", "roughly", "about", "around",
          "sort of", "kind of", "i think", "i suspect", "arguably", "fairly",
          "pretty", "quite", "a bit", "slightly", "honestly", "frankly"}

ABBREV = ("e.g.", "i.e.", "et al.", "vs.", "fig.", "no.", "vol.", "pp.",
          "dr.", "mr.", "mrs.", "ms.", "prof.", "eq.", "ref.", "cf.", "al.")

_SENT_SPLIT = re.compile(
    r"(?<=\be\.g)(?<=\bi\.e)|(?<=et al)|(?<=[\s\S]{0,0})", re.UNICODE
)

_SENT_END = re.compile(r"[.!?]+[\"'\u201d\u2019)\]]*(?=\s)")


# --------------------------------------------------------------------------- utils
def split_sentences(text: str) -> list[dict]:
    """Sentence segmentation that returns character offsets."""
    out: list[dict] = []
    start = 0
    n = len(text)
    i = 0
    while i < n:
        ch = text[i]
        if ch in ".!?":
            j = i + 1
            while j < n and text[j] in "\"'\u201d\u2019)]":
                j += 1
            if j >= n or text[j].isspace():
                candidate = text[start:i + 1]
                low = candidate.lower()
                tail = low[-12:]
                if any(tail.endswith(a) for a in ABBREV) or re.search(r"\b[a-z]\.$", low.strip()):
                    i = j
                    continue
                _push(out, text, start, i + 1)
                start = j
                i = j
                continue
        i += 1
    _push(out, text, start, n)
    return out


def _push(out, text, start, end):
    raw = text[start:end]
    stripped = raw.strip()
    if len(stripped) < 2:
        return
    lead = len(raw) - len(raw.lstrip())
    trail = len(raw) - len(raw.rstrip())
    out.append({
        "start": start + lead,
        "end": end - trail,
        "text": stripped,
        "words": len(re.findall(r"[A-Za-z0-9']+", stripped)),
    })


def split_blocks(text: str, sentences: list[dict]) -> list[dict]:
    """Group sentences into paragraphs using blank-line / newline boundaries."""
    blocks: list[dict] = []
    cur: list[dict] = []
    last_end = 0
    for s in sentences:
        gap = text[last_end:s["start"]]
        if cur and ("\n\n" in gap or text[last_end:s["start"]].count("\n") >= 2):
            blocks.append({"sentences": cur})
            cur = []
        cur.append(s)
        last_end = s["end"]
    if cur:
        blocks.append({"sentences": cur})
    if len(blocks) <= 1 and len(sentences) > 6:
        # fall back: chunk into ~5-sentence blocks so the UI can show a breakdown
        blocks = [{"sentences": sentences[i:i + 5]} for i in range(0, len(sentences), 5)]
    return blocks


def _freq(tokens: list[str], items: set[str]) -> float:
    if not tokens:
        return 0.0
    return 100.0 * sum(1 for t in tokens if t in items) / len(tokens)


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def _msttr(tokens: list[str], window: int = 500) -> float:
    """Mean segmental type-token ratio -- length-independent diversity."""
    if len(tokens) < window:
        return len(set(tokens)) / max(1, len(tokens))
    ratios = []
    for i in range(0, len(tokens) - window + 1, window):
        seg = tokens[i:i + window]
        ratios.append(len(set(seg)) / window)
    return sum(ratios) / len(ratios)


def _entropy(tokens: list[str]) -> float:
    if not tokens:
        return 0.0
    counts = Counter(tokens)
    total = len(tokens)
    h = -sum((c / total) * math.log2(c / total) for c in counts.values())
    return h


# --------------------------------------------------------------------------- core
def analyze(text: str) -> dict:
    sentences = split_sentences(text)
    blocks = split_blocks(text, sentences)
    words = re.findall(r"[A-Za-z0-9']+", text)
    low = text.lower()
    tokens = [w.lower() for w in words]
    n_words = len(tokens)

    if n_words < 40:
        return {
            "available": False,
            "score": None,
            "message": "Not enough text to score reliably (40 words minimum).",
            "words": n_words,
        }

    lens = [s["words"] for s in sentences if s["words"] > 0]
    mean_len = sum(lens) / len(lens)
    var = sum((x - mean_len) ** 2 for x in lens) / len(lens)
    std_len = math.sqrt(var)
    cv = std_len / mean_len if mean_len else 0.0
    # burstiness: (std - mean) / (std + mean) -- human text usually higher
    burstiness = (std_len - mean_len) / (std_len + mean_len) if (std_len + mean_len) else 0.0

    # sentence-length uniformity: share of sentences within +/-20% of the mean
    uniform = sum(1 for x in lens if abs(x - mean_len) <= 0.2 * mean_len) / len(lens)

    cliche_hits: dict[str, int] = {}
    for phrase in AI_PHRASES:
        c = low.count(phrase)
        if c:
            cliche_hits[phrase] = c
    cliche_total = sum(cliche_hits.values())
    cliche_per100 = 100.0 * cliche_total / n_words

    transition_per100 = _freq(tokens, TRANSITIONS)
    contraction_per100 = _freq(tokens, CONTRACTIONS)
    first_person_per100 = _freq(tokens, FIRST_PERSON)
    hedge_per100 = sum(low.count(h) for h in HEDGES) * 100.0 / n_words

    punct_marks = low.count(";") + low.count(":") + low.count("(") + low.count("\u2014") + low.count(" - ")
    punct_per100 = 100.0 * punct_marks / n_words

    # nominalisation density: -tion/-ment/-ance/-ity/-ness endings, a hallmark of
    # abstract machine prose
    nominal = sum(1 for w in tokens if len(w) > 6 and w.endswith(
        ("tion", "sion", "ment", "ance", "ence", "ity", "ness", "isation", "ization")))
    nominal_per100 = 100.0 * nominal / n_words

    ttr = _msttr(tokens)
    ent = _entropy(tokens)

    # template repetition: how often the same 5-word opening recurs
    openers = Counter(" ".join(t.split()[:5]).lower() for t in
                      [s["text"] for s in sentences] if len(t.split()) >= 5)
    opener_rep = sum(c - 1 for c in openers.values() if c > 1) / max(1, len(sentences))

    # dangling-participle / "not only ... but also" scaffolding
    scaffold = low.count("not only") + low.count("as well as") + low.count("in order to")

    components = {
        "cliche_density": _clamp(cliche_per100 / 2.2),
        "sentence_uniformity": _clamp((uniform - 0.30) / 0.55),
        # machine text clusters around cv ~0.30-0.40, human prose around 0.55-0.80
        "low_length_variation": _clamp((0.62 - cv) / 0.30),
        "transition_loading": _clamp(transition_per100 / 2.0),
        "missing_contractions": _clamp(1 - contraction_per100 / 1.2),
        "flat_punctuation": _clamp(1 - punct_per100 / 1.6),
        "low_diversity": _clamp((0.72 - ttr) / 0.15),
        "template_repetition": _clamp(opener_rep / 0.25),
        "impersonal_voice": _clamp(1 - first_person_per100 / 0.55),
        "long_sentences": _clamp((mean_len - 16) / 14),
        "abstraction_density": _clamp((nominal_per100 - 3.0) / 5.0),
    }
    weights = {
        "cliche_density": 0.19,
        "sentence_uniformity": 0.14,
        "low_length_variation": 0.18,
        "transition_loading": 0.10,
        "missing_contractions": 0.05,
        "flat_punctuation": 0.05,
        "low_diversity": 0.06,
        "template_repetition": 0.05,
        "impersonal_voice": 0.06,
        "long_sentences": 0.05,
        "abstraction_density": 0.07,
    }
    raw = sum(weights[k] * components[k] for k in weights)
    # logistic squash centred so that raw 0.42 maps to 50%
    score = 100.0 / (1.0 + math.exp(-(raw - 0.42) * 8.5))
    score = round(score, 2)

    # ---------- sentence level
    doc_norm = score / 100.0
    per_sentence = []
    for s in sentences:
        st = s["text"].lower()
        st_tokens = re.findall(r"[A-Za-z0-9']+", st)
        if not st_tokens:
            continue
        local_cliche = sum(st.count(p) for p in AI_PHRASES)
        local_cliche_n = _clamp(local_cliche / max(1, len(st_tokens) / 26.0))
        local_trans = _clamp(_freq(st_tokens, TRANSITIONS) / 2.5)
        local_contract = 0.0 if any(t in CONTRACTIONS for t in st_tokens) else 1.0
        local_punct = 0.0 if any(ch in s["text"] for ch in ";:\u2014(") else 1.0
        len_fit = _clamp(1 - abs(s["words"] - mean_len) / max(6.0, mean_len))
        local_raw = (0.34 * local_cliche_n + 0.20 * local_trans + 0.16 * local_contract
                     + 0.14 * local_punct + 0.16 * len_fit)
        blended = 0.52 * doc_norm + 0.48 * local_raw
        s_score = round(100.0 / (1.0 + math.exp(-(blended - 0.45) * 8.0)), 1)
        per_sentence.append({
            "start": s["start"],
            "end": s["end"],
            "words": s["words"],
            "score": s_score,
            "flags": _flags(s["text"], local_cliche, st_tokens),
        })

    block_out = []
    for b in blocks:
        ss = [p for p in per_sentence
              if any(p["start"] == x["start"] for x in b["sentences"])]
        if not ss:
            continue
        wsum = sum(p["words"] for p in ss) or 1
        bscore = sum(p["score"] * p["words"] for p in ss) / wsum
        text_start = ss[0]["start"]
        preview = text[text_start:text_start + 160].replace("\n", " ")
        block_out.append({
            "score": round(bscore, 1),
            "words": wsum,
            "sentences": len(ss),
            "preview": preview,
            "start": text_start,
            "end": ss[-1]["end"],
        })

    # AI-most and most-human sentences for the evidence panel (short previews so the
    # stored result stays small even for very large documents)
    ranked = sorted(per_sentence, key=lambda p: p["score"], reverse=True)
    by_offset = {p["start"]: p for p in per_sentence}
    for p in per_sentence:
        p.pop("text", None)

    def with_preview(p):
        out = dict(p)
        out["preview"] = text[p["start"]:p["end"]][:320]
        return out

    return {
        "available": True,
        "score": score,
        "verdict": _verdict(score),
        "words": n_words,
        "sentences": len(per_sentence),
        "blocks": block_out,
        "per_sentence": per_sentence,
        "metrics": {
            "avg_sentence_words": round(mean_len, 1),
            "sentence_length_std": round(std_len, 1),
            "burstiness": round(burstiness, 3),
            "length_cv": round(cv, 3),
            "abstraction_per_100w": round(nominal_per100, 2),
            "length_uniformity": round(uniform, 3),
            "cliche_per_100w": round(cliche_per100, 2),
            "transition_per_100w": round(transition_per100, 2),
            "contraction_per_100w": round(contraction_per100, 2),
            "first_person_per_100w": round(first_person_per100, 2),
            "hedge_per_100w": round(hedge_per100, 2),
            "punctuation_per_100w": round(punct_per100, 2),
            "lexical_diversity": round(ttr, 3),
            "entropy_bits": round(ent, 2),
            "type_token_ratio": round(len(set(tokens)) / n_words, 3),
            "scaffold_phrases": scaffold,
        },
        "components": {k: round(v, 3) for k, v in components.items()},
        "cliche_hits": dict(sorted(cliche_hits.items(), key=lambda kv: -kv[1])[:25]),
        "evidence": [with_preview(p) for p in ranked[:4]],
        "human_examples": [with_preview(p) for p in ranked[-3:] if p["score"] < 40],
    }


def _flags(sentence: str, cliche_count: int, tokens: list[str]) -> list[str]:
    flags = []
    if cliche_count:
        flags.append("formulaic phrase")
    if any(t in TRANSITIONS for t in tokens):
        flags.append("transition opener")
    if not any(t in CONTRACTIONS for t in tokens) and len(tokens) > 12:
        flags.append("no contraction")
    if not any(ch in sentence for ch in ";:\u2014("):
        flags.append("flat punctuation")
    return flags[:3]


def _verdict(score: float) -> str:
    if score >= 75:
        return "Strongly AI-like"
    if score >= 55:
        return "Likely AI-assisted"
    if score >= 35:
        return "Mixed signals"
    return "Mostly human-style"


def compare_documents(a: dict, b: dict) -> dict:
    """Rough delta view used by the UI when two runs are compared."""
    return {
        "score_delta": round((b.get("score") or 0) - (a.get("score") or 0), 2),
        "verdict_a": a.get("verdict"),
        "verdict_b": b.get("verdict"),
    }
