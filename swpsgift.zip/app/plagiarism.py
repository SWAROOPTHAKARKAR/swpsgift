"""Corpus + web plagiarism engine.

Matching is done with rolling-hash k-gram fingerprints (k = 8 words). Passages
are reconstructed by extending exact token runs, so the report shows the actual
overlapping text rather than a bag of shingles.

The corpus is whatever you put in the Library: every stored document is
fingerprinted once and compared against every future submission. Web checking is
optional and only runs when a search API key is configured.
"""
from __future__ import annotations

import json
import math
import os
import re
import unicodedata
import urllib.parse
import urllib.request
from collections import defaultdict

import numpy as np

K = 8            # shingle size for corpus matching (words)
K_REPEAT = 12    # shingle size for internal repetition
MIN_PASSAGE = 12  # words

_TOKEN = re.compile(r"[a-z0-9']+", re.IGNORECASE)


def normalize(text: str) -> str:
    text = unicodedata.normalize("NFKD", text)
    text = text.replace("\u2019", "'").replace("\u2018", "'")
    return text


def tokenize(text: str) -> tuple[list[str], list[tuple[int, int]]]:
    tokens, spans = [], []
    for m in _TOKEN.finditer(text):
        tokens.append(m.group(0).lower())
        spans.append((m.start(), m.end()))
    return tokens, spans


def fingerprints(token_ids: np.ndarray, k: int) -> np.ndarray:
    """Polynomial rolling hash over a token-id array, mod 2**64."""
    n = len(token_ids)
    if n < k:
        return np.empty(0, dtype=np.uint64)
    base = np.uint64(0x100000001B3)
    mask = (1 << 64) - 1
    out = np.empty(n - k + 1, dtype=np.uint64)
    h = 0
    for i in range(k):
        h = ((h * int(base)) + int(token_ids[i]) + 1) & mask
    out[0] = np.uint64(h)
    highest = pow(int(base), k - 1, 1 << 64)
    for i in range(1, n - k + 1):
        h = ((h - (int(token_ids[i - 1]) + 1) * highest) & mask)
        h = ((h * int(base)) + int(token_ids[i + k - 1]) + 1) & mask
        out[i] = np.uint64(h)
    return out


def token_ids_for(tokens: list[str]) -> np.ndarray:
    vocab: dict[str, int] = {}
    ids = np.empty(len(tokens), dtype=np.uint32)
    for i, t in enumerate(tokens):
        idx = vocab.get(t)
        if idx is None:
            idx = len(vocab) + 1
            vocab[t] = idx
        ids[i] = idx
    return ids


def digest(text: str) -> np.ndarray:
    tokens, _ = tokenize(text)
    return fingerprints(token_ids_for(tokens), K)


# --------------------------------------------------------------------------- web
WEB_PROVIDERS = ("serpapi", "google_cse")


def web_status() -> dict:
    if os.environ.get("SERPAPI_KEY"):
        return {"enabled": True, "provider": "SerpAPI"}
    if os.environ.get("GOOGLE_API_KEY") and os.environ.get("GOOGLE_CSE_ID"):
        return {"enabled": True, "provider": "Google Programmable Search"}
    return {
        "enabled": False,
        "reason": "Web checking is off. Set SERPAPI_KEY (or GOOGLE_API_KEY + "
                  "GOOGLE_CSE_ID) in the environment to search the live web.",
    }


def _search(query: str, limit: int = 4) -> list[dict]:
    key = os.environ.get("SERPAPI_KEY")
    try:
        if key:
            url = ("https://serpapi.com/search.json?"
                   + urllib.parse.urlencode({"q": query, "num": limit, "engine": "google", "api_key": key}))
        else:
            url = ("https://www.googleapis.com/customsearch/v1?"
                   + urllib.parse.urlencode({
                       "q": query, "num": min(limit, 10),
                       "key": os.environ.get("GOOGLE_API_KEY", ""),
                       "cx": os.environ.get("GOOGLE_CSE_ID", ""),
                   }))
        req = urllib.request.Request(url, headers={"User-Agent": "SWPsGift/1.0"})
        with urllib.request.urlopen(req, timeout=12) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
    except Exception as exc:
        return [{"error": str(exc)}]

    hits = []
    if "organic_results" in data:
        for item in data["organic_results"][:limit]:
            hits.append({"title": item.get("title", ""), "url": item.get("link", ""),
                         "snippet": item.get("snippet", "")})
    elif "items" in data:
        for item in data["items"][:limit]:
            hits.append({"title": item.get("title", ""), "url": item.get("link", ""),
                         "snippet": item.get("snippet", "")})
    elif "error" in data:
        err = data.get("error")
        if isinstance(err, dict):
            msg = err.get("message") or err.get("errors", [{}])[0].get("message", "")
            code = err.get("code")
            return [{"error": f"Google API error {code}: {str(msg)[:180]}"}]
        return [{"error": str(err)[:200]}]
    return hits


def _similarity(a: str, b: str, k: int = 5) -> float:
    """Share of a's k-grams that also occur in b. Order matters, so n-grams are
    built from token sequences -- never from an unordered set."""
    ta = [t.lower() for t in _TOKEN.findall(a)]
    tb = [t.lower() for t in _TOKEN.findall(b)]
    if len(ta) < k or len(tb) < k:
        return 0.0
    grams_a = [" ".join(ta[i:i + k]) for i in range(len(ta) - k + 1)]
    grams_b = {" ".join(tb[i:i + k]) for i in range(len(tb) - k + 1)}
    hit = sum(1 for g in grams_a if g in grams_b)
    return round(100.0 * hit / len(grams_a), 1)


def web_check(text: str, max_queries: int = 8) -> dict:
    # keep the free daily quota under control; override with WEB_MAX_QUERIES
    try:
        max_queries = max(1, int(os.environ.get("WEB_MAX_QUERIES", max_queries)))
    except (TypeError, ValueError):
        pass
    status = web_status()
    if not status["enabled"]:
        return {"enabled": False, "reason": status["reason"], "matches": []}

    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if len(s.split()) >= 10]
    if not sentences:
        return {"enabled": True, "matches": [], "queries": 0}
    step = max(1, len(sentences) // max_queries)
    sample = sentences[::step][:max_queries]

    matches, errors = [], []
    for sentence in sample:
        query = " ".join(sentence.split()[:18])
        for hit in _search(query, limit=3):
            if "error" in hit:
                errors.append(hit["error"])
                continue
            sim = _similarity(sentence, f"{hit.get('title','')} {hit.get('snippet','')}")
            if sim >= 35:
                matches.append({
                    "query": query,
                    "similarity": sim,
                    "title": hit.get("title", ""),
                    "url": hit.get("url", ""),
                    "snippet": hit.get("snippet", ""),
                })
    matches.sort(key=lambda m: -m["similarity"])
    return {
        "enabled": True,
        "provider": status["provider"],
        "queries": len(sample),
        "matches": matches[:25],
        "errors": errors[:3],
    }


# --------------------------------------------------------------------------- core
def analyze(text: str, corpus: list[dict], fp_loader, src_loader,
            progress=None, do_web: bool = False) -> dict:
    """corpus: [{id, name, words}]; fp_loader(id)->np.ndarray; src_loader(id)->str"""
    tokens, spans = tokenize(text)
    n = len(tokens)
    result: dict = {
        "words": n,
        "coverage_pct": 0.0,
        "sources": [],
        "matches": [],
        "internal_repeats": [],
        "corpus_size": len(corpus),
        "web": {"enabled": False, "matches": [], "reason": "skipped"},
    }
    if n < 20:
        result["message"] = "Not enough text to compare (20 words minimum)."
        return result

    ids = token_ids_for(tokens)
    sub_fps = fingerprints(ids, K)
    if progress:
        progress(20, "Fingerprinting submission")

    matched_positions = np.zeros(len(sub_fps), dtype=bool)
    per_doc: dict[int, np.ndarray] = {}

    for i, doc in enumerate(corpus):
        if progress and i % 5 == 0:
            progress(20 + int(45 * i / max(1, len(corpus))), f"Comparing against {doc['name'][:40]}")
        try:
            fps = fp_loader(doc["id"])
        except Exception:
            continue
        if fps is None or len(fps) == 0:
            continue
        mask = np.isin(sub_fps, fps, assume_unique=False)
        if mask.any():
            per_doc[doc["id"]] = mask
            matched_positions |= mask

    if progress:
        progress(68, "Reconstructing overlapping passages")

    total_matched_tokens = _unique_token_coverage(sub_fps, matched_positions, K)

    sources = []
    all_matches = []
    for doc in corpus:
        mask = per_doc.get(doc["id"])
        if mask is None:
            continue
        try:
            src_text = src_loader(doc["id"])
        except Exception:
            continue
        src_tokens, src_spans = tokenize(src_text)
        src_ids = token_ids_for(src_tokens)
        src_fps = fingerprints(src_ids, K)
        pos_index: dict[int, list[int]] = defaultdict(list)
        for p, fp in enumerate(src_fps.tolist()):
            pos_index[fp].append(p)

        passages = _extract_passages(tokens, spans, sub_fps, mask, src_tokens,
                                     src_spans, src_text, pos_index, K)
        if not passages:
            continue
        matched_words = sum(p["words"] for p in passages)
        pct = round(100.0 * matched_words / n, 2)
        sources.append({
            "doc_id": doc["id"],
            "name": doc["name"],
            "words": doc.get("words") or len(src_tokens),
            "matched_words": matched_words,
            "pct_of_submission": pct,
            "passages": passages[:12],
            "passage_count": len(passages),
        })
        for p in passages[:8]:
            m = dict(p)
            m["source"] = doc["name"]
            all_matches.append(m)

    sources.sort(key=lambda s: -s["matched_words"])
    all_matches.sort(key=lambda m: -m["words"])

    coverage = round(100.0 * total_matched_tokens / n, 2)
    result.update({
        "coverage_pct": coverage,
        "matched_tokens": total_matched_tokens,
        "sources": sources[:20],
        "matches": all_matches[:40],
    })

    if progress:
        progress(80, "Checking internal repetition")
    result["internal_repeats"] = internal_repeats(tokens, spans, text)

    if do_web:
        if progress:
            progress(88, "Searching the web")
        result["web"] = web_check(text)
    if progress:
        progress(96, "Scoring")

    result["verdict"] = _verdict(coverage, len(sources))
    return result


def _unique_token_coverage(sub_fps, mask, k) -> int:
    """Count distinct token positions covered by at least one matched shingle."""
    if not mask.any():
        return 0
    covered = np.zeros(len(sub_fps) + k - 1, dtype=bool)
    for offset in range(k):
        idx = np.nonzero(mask)[0]
        idx = idx[idx + offset < len(covered)]
        covered[idx + offset] = True
    return int(covered.sum())


def _extract_passages(sub_tokens, sub_spans, sub_fps, mask, src_tokens, src_spans,
                      src_text, pos_index, k) -> list[dict]:
    hits = np.nonzero(mask)[0]
    if len(hits) == 0:
        return []
    passages = []
    used_sub = set()
    anchors = hits[:600].tolist()
    for pos in anchors:
        if pos in used_sub:
            continue
        fp = int(sub_fps[pos])
        candidates = pos_index.get(fp, [])
        if not candidates:
            continue
        best = None
        for src_pos in candidates[:4]:
            fwd = 0
            while (pos + fwd < len(sub_tokens) and src_pos + fwd < len(src_tokens)
                   and sub_tokens[pos + fwd] == src_tokens[src_pos + fwd]):
                fwd += 1
            back = 0
            while (pos - back - 1 >= 0 and src_pos - back - 1 >= 0
                   and sub_tokens[pos - back - 1] == src_tokens[src_pos - back - 1]):
                back += 1
            length = fwd + back
            if best is None or length > best[0]:
                best = (length, src_pos - back, pos - back)
        if not best or best[0] < MIN_PASSAGE:
            continue
        length, src_start, sub_start = best
        for p in range(sub_start, sub_start + length):
            used_sub.add(p)
        sub_text = _slice_text(sub_tokens, sub_spans, sub_start, length)
        src_slice = _slice_text(src_tokens, src_spans, src_start, length)
        passages.append({
            "text": sub_text[:1200],
            "source_excerpt": src_slice[:1200],
            "words": length,
            "start": sub_spans[sub_start][0] if sub_start < len(sub_spans) else 0,
            "end": sub_spans[min(len(sub_spans) - 1, sub_start + length - 1)][1],
            "similarity": 100.0,
        })
    passages.sort(key=lambda p: -p["words"])
    # drop heavily overlapping duplicates
    kept, seen = [], []
    for p in passages:
        if any(abs(p["start"] - s) < 60 for s in seen):
            continue
        kept.append(p)
        seen.append(p["start"])
    return kept[:40]


def _slice_text(tokens, spans, start, length) -> str:
    if start < 0 or start >= len(spans):
        return ""
    end_idx = min(len(spans) - 1, start + length - 1)
    return " ".join(tokens[start:start + length])


def internal_repeats(tokens, spans, text) -> list[dict]:
    if len(tokens) < K_REPEAT * 2:
        return []
    ids = token_ids_for(tokens)
    fps = fingerprints(ids, K_REPEAT)
    if len(fps) == 0:
        return []
    counts = np.bincount(fps.astype(np.int64) % (1 << 20), minlength=1 << 20)
    seen: dict[str, int] = {}
    for pos, fp in enumerate(fps.tolist()):
        if counts[fp % (1 << 20)] < 2:
            continue
        phrase = " ".join(tokens[pos:pos + K_REPEAT])
        seen[phrase] = seen.get(phrase, 0) + 1
    top = sorted(seen.items(), key=lambda kv: -kv[1])[:12]
    return [{"phrase": p[:200], "count": c} for p, c in top if c > 1]


def _verdict(coverage: float, sources: int) -> str:
    if coverage >= 40:
        return "High overlap"
    if coverage >= 20:
        return "Significant overlap"
    if coverage >= 8:
        return "Some overlap"
    return "Largely original"
