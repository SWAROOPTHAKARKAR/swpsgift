# SWP'sGift

A free website that checks documents for **AI-generated writing** and **plagiarised text**.
No word limit, 25 MB per file, no sign-up.

- **AI-likeness** — stylometric scoring (burstiness, sentence-length uniformity, formulaic
  phrases, transition loading, contractions, punctuation variety, lexical diversity, template
  repetition, abstraction density) with a score per sentence, per paragraph and for the document.
- **Plagiarism** — eight-word rolling-hash fingerprints compared against a reference library you
  build yourself, with matched passages reconstructed and shown side by side with the source.
- **Optional web search** — checks distinctive sentences against public search results when an API
  key is configured.
- **Reports** — every check gets a clean printable report page.

## Pages

| Route | What it is |
|---|---|
| `/` | Home — what the site does, how scoring works, FAQ |
| `/check` | The checker: upload or paste, live progress, results |
| `/library` | Reference library used by the plagiarism engine |
| `/how-it-works` | Methodology, calibration figures and limits |
| `/api/report/{job_id}` | Printable report for a completed check |
| `/api/docs` | OpenAPI docs for the JSON API |

## Run locally

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
# open http://localhost:8000
```

Or with Docker:

```bash
docker build -t swpsgift .
docker run -p 8000:7860 -v "$PWD/data:/data" swpsgift
```

## Configuration

| Variable | Default | Purpose |
|---|---|---|
| `DATA_DIR` | `./data` | SQLite database, extracted text, fingerprints, job results |
| `SERPAPI_KEY` | — | Enables web checking through SerpAPI |
| `GOOGLE_API_KEY` + `GOOGLE_CSE_ID` | — | Alternative web-check provider (Programmable Search) |
| `PORT` | `8000` | Port used by the Procfile start command |

## How it is put together

```
app/
  main.py         FastAPI routes, upload handling, background jobs, report renderer
  extract.py      text extraction: PDF, DOCX, PPTX, XLSX, TXT, MD, CSV, RTF, HTML
  ai_detect.py    stylometric AI-text detector (explainable, no model download)
  plagiarism.py   k-gram fingerprinting, passage reconstruction, internal repetition, web check
  store.py        SQLite metadata + on-disk artifacts and fingerprint cache
  site/           the website: base.html shell, home, check, library, how-it-works
```

**Why no pretrained model?** A local transformer would need hundreds of MB and would not fit a
free 512 MB container. The stylometric route starts instantly, runs inside any free tier, and — the
part that matters — is explainable: every score can be traced to specific signals and specific
sentences. Its weakness is the middle band, and the site says so instead of hiding it.

**Why the library matters.** Plagiarism matching is only as good as what it compares against. The
library starts empty, so the first checks will report 0% overlap until you add reference documents.

## Honest limitations

- No detector can prove authorship. Treat scores as pointers to passages worth reading.
- Paraphrased copying that shares no eight-word sequence will not be flagged.
- Scanned PDFs need OCR before upload.
- Web checking is off unless an API key is set.

## Deploying for free

See [DEPLOY.md](DEPLOY.md) for step-by-step instructions for Hugging Face Spaces and Render.
